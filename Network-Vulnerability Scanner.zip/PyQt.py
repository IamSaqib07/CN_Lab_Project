import sys
import nmap
import ipaddress
import time
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit, QComboBox, QFileDialog


class NmapTool(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Nmap Automation Tool")
        self.setGeometry(100, 100, 400, 300)

        self.scanner = nmap.PortScanner()

        # UI Elements
        self.ip_label = QLabel("Enter IP Address:")
        self.ip_input = QLineEdit(self)
        self.scan_type_label = QLabel("Select Scan Type:")
        self.scan_type_combo = QComboBox(self)
        self.scan_type_combo.addItem("SYN ACK Scan")
        self.scan_type_combo.addItem("UDP Scan")
        self.scan_type_combo.addItem("Comprehensive Scan")

        self.scan_button = QPushButton("Start Scan", self)
        self.save_button = QPushButton("Save Results", self)
        self.result_label = QLabel("Results will be displayed here.", self)

        # Layouts
        layout = QVBoxLayout()
        layout.addWidget(self.ip_label)
        layout.addWidget(self.ip_input)
        layout.addWidget(self.scan_type_label)
        layout.addWidget(self.scan_type_combo)
        layout.addWidget(self.scan_button)
        layout.addWidget(self.result_label)
        layout.addWidget(self.save_button)

        self.setLayout(layout)

        # Connecting buttons to functions
        self.scan_button.clicked.connect(self.start_scan)
        self.save_button.clicked.connect(self.save_results)

    def start_scan(self):
        ip_addr = self.ip_input.text()

        # Validate the IP format
        try:
            ipaddress.ip_address(ip_addr)
        except ValueError:
            self.result_label.setText("Invalid IP address format.")
            return

        scan_type = self.scan_type_combo.currentText()
        if scan_type == 'SYN ACK Scan':
            self.run_syn_scan(ip_addr)
        elif scan_type == 'UDP Scan':
            self.run_udp_scan(ip_addr)
        elif scan_type == 'Comprehensive Scan':
            self.run_comprehensive_scan(ip_addr)

    def run_syn_scan(self, ip_addr):
        self.scanner.scan(ip_addr, '1-1024', '-v -sS')
        self.display_results(ip_addr)

    def run_udp_scan(self, ip_addr):
        self.scanner.scan(ip_addr, '1-1024', '-v -sU')
        self.display_results(ip_addr)

    def run_comprehensive_scan(self, ip_addr):
        self.scanner.scan(ip_addr, '1-1024', '-v -sS -sV -sC -A -O')
        self.display_results(ip_addr)

    def display_results(self, ip_addr):
        try:
            ip_status = self.scanner[ip_addr].state()
            open_ports = self.scanner[ip_addr].all_protocols()
            open_ports = self.scanner[ip_addr]['tcp'].keys() if 'tcp' in open_ports else []

            result = f"IP Status: {ip_status}\nOpen Ports: {', '.join(map(str, open_ports))}"
            self.result_label.setText(result)
        except KeyError:
            self.result_label.setText("Scan failed or no open ports detected.")

    def save_results(self):
        # Open file dialog for user to choose where to save the results
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Scan Results", "", "Text Files (*.txt);;All Files (*)", options=options)
        if file_path:
            try:
                # Adding timestamp and scan results to the file
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
                ip_addr = self.ip_input.text()
                with open(file_path, "a") as f:
                    f.write(f"\n\n--- Scan Results ({timestamp}) ---\n")
                    f.write(f"IP Address: {ip_addr}\n")
                    f.write(f"Scan Info: {str(self.scanner.scaninfo())}\n")
                    f.write(f"IP Status: {self.scanner[ip_addr].state()}\n")
                    
                    # Writing open ports (TCP/UDP)
                    if 'tcp' in self.scanner[ip_addr]:
                        f.write(f"Open Ports (TCP): {', '.join(map(str, self.scanner[ip_addr]['tcp'].keys()))}\n")
                    if 'udp' in self.scanner[ip_addr]:
                        f.write(f"Open Ports (UDP): {', '.join(map(str, self.scanner[ip_addr]['udp'].keys()))}\n")

                self.result_label.setText(f"Results saved to {file_path}")
            except Exception as e:
                self.result_label.setText(f"Error saving results: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = NmapTool()
    window.show()
    sys.exit(app.exec_())
