import nmap

scanner = nmap.PortScanner()

print("Welcome, this is a simple nmap automation tool")
print("<----------------------------------------------------->")

import ipaddress

while True:
    try:
        ip_addr = input("Please enter the IP address you want to scan: ")
        ipaddress.ip_address(ip_addr)  # Validate IP format
        break  
    except ValueError:
        print("Invalid IP address format. Please try again.")


resp = input("""\nPlease enter the type of scan you want to run
                1)SYN ACK Scan
                2)UDP Scan
                3)Comprehensive Scan \n""")
print("You have selected option: ", resp)

if resp == '1':
    print("Nmap Version: ", scanner.nmap_version())
    scanner.scan(ip_addr, '1-1024', '-v -sS')
    print(scanner.scaninfo())
    print("Ip Status: ", scanner[ip_addr].state())
    print(scanner[ip_addr].all_protocols())
    print("Open Ports: ", scanner[ip_addr]['tcp'].keys())
elif resp == '2':
    print("Nmap Version: ", scanner.nmap_version())
    scanner.scan(ip_addr, '1-1024', '-v -sU')
    print(scanner.scaninfo())
    print("Ip Status: ", scanner[ip_addr].state())
    print(scanner[ip_addr].all_protocols())
    print("Open Ports: ", scanner[ip_addr]['udp'].keys())
elif resp == '3':
    print("Nmap Version: ", scanner.nmap_version())
    scanner.scan(ip_addr, '1-1024', '-v -sS -sV -sC -A -O')
    print(scanner.scaninfo())
    print("Ip Status: ", scanner[ip_addr].state())
    print(scanner[ip_addr].all_protocols())
    print("Open Ports: ", scanner[ip_addr]['tcp'].keys())
elif resp >= '4':
    print("Please enter a valid option")


save_option = input("Do you want to save the scan results to a file? (y/n): ")
if save_option.lower() == 'y':
    with open(r"C:\Users\Hassan Nawaz\Desktop\new\scan_results.txt", "a") as f:
        f.write(f"Scan Results for IP: {ip_addr}\n")
        f.write(str(scanner.scaninfo()))
        f.write(f"\nIp Status: {scanner[ip_addr].state()}")
        f.write(f"\nOpen Ports: {scanner[ip_addr]['tcp'].keys()}\n")
        f.write("-" * 50 + "\n")  # Adds a separator for clarity between results
    print("Results saved to scan_results.txt")






